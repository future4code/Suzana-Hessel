import { Router } from './router';
import './index.css';

function App() {
  return (
    <Router />
  );
}

export default App;
