import { useEffect, useState } from 'react';
import { getRestaurants } from '../../utils/api';
import { RestaurantCard, SearchBox } from '../../components';
import { Header, PageTitle, RestaurantCardsContainer } from './styles';

export const HomePage = () => {

    const [restaurants, setRestaurants] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");

    const onChangeSearchTerm = (e) => {
        setSearchTerm(e.target.value);
    }
    useEffect(() => {
        // const fetch = () => {

        // }
        // fetch(); // documentação do React. Ver Notion
        getRestaurants()
        .then((resposta) => {
            setRestaurants(resposta.response)
        })
    }, []);

    const filterRestaurants = (restaurant) => {
        if(searchTerm === "") return true;
        if(restaurant.name.includes(searchTerm)) return true;
        return false;
    }
    
    return (
        <>
            <Header />
            <PageTitle>Bem-vindo ao Labenu Rango</PageTitle>
            <SearchBox value={searchTerm} onChange={onChangeSearchTerm}/>
            <RestaurantCardsContainer>
                {restaurants.filter(filterRestaurants).map((restaurant,i) => (
                    <RestaurantCard key={restaurant.id} name={restaurant.name} address={restaurant.address}/>)
                )}
            </RestaurantCardsContainer>

        </>
    )
}