export * from './home'; // não é preciso colocar /index.
export * from './details';