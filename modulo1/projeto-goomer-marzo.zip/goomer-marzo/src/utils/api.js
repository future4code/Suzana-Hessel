import axios from 'axios';

export const getRestaurants = async () => {
    let error;
    let response;
    try {
        const { data } = await axios.get('http://challange.goomer.com.br/restaurants');
        response = data;
        // axios.get('http://challange.goomer.com.br/restaurants')
        // .then(({ data }) => {
        //     console.log(data);
        //     response = data;
        // }) // é a mesma coisa que as duas linhas acima
    } catch(e) {
        error = e;
    }
    return {
        error,
        response
    }
}

// const { response, error } = await getRestaurants()